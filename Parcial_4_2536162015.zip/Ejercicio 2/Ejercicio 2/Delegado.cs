﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    delegate double Delegado(double Venta);
    class Operacion
    {
        public static double Descuento(double Venta, Delegado dlg)
        {
            return dlg(Venta);
        }
    }
}
