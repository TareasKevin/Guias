﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el total de la compra que a realizado: ");
            double Venta = Convert.ToDouble(Console.ReadLine());
            double A = (Venta - (Venta * 0.10));
            double B = (Venta - (Venta * 0.30));
            double C = (Venta - (Venta * 0.50));
            var Total = Operacion.Descuento(Venta, desc => 
            {
                if (Venta > 10000 && Venta <= 20000)
                {
                    return A;
                }
                else if (Venta > 20001 && Venta <= 50000)
                {
                    return B;
                }
                else if (Venta > 50000)
                {
                    return C;
                }

             return Venta * 1;
           }
            );

            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("Su total a pagar es: {0}", Total);
            Console.ReadKey();
        }
    }
}

