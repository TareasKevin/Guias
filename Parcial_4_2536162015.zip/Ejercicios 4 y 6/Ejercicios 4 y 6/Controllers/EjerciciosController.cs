﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ejercicios_4_y_6.Models;

namespace Ejercicios_4_y_6.Controllers
{
    public class EjerciciosController : Controller
    {
        // GET: Ejercicios
        public ActionResult Ejercicio4()
        {
            return View();
        }

        public ActionResult Ejercicio6()
        {
            return View();
        }

        //POST
        [HttpPost]
        public ActionResult Ejercicio4(Valores ObjModel)
        {
            double Promedio = (ObjModel.Nota1 + ObjModel.Nota2 + ObjModel.Nota3) / 3;

            if (ObjModel.Nota1 > 5 | ObjModel.Nota2 > 5 | ObjModel.Nota3 > 5 | ObjModel.Nota1 < 0 | ObjModel.Nota2 < 0 | ObjModel.Nota3 < 0)
            {
                string mensaje = "INGRESE LOS DATOS CORRECTAMENTE";
                ViewBag.mensaje = mensaje;
            }
            else
            {
                ViewBag.Codigo = "Codigo del estudiante: " + ObjModel.Codigo;
                ViewBag.Nombre = "Nombre: " + ObjModel.Nombre;
                ViewBag.Materia = "Materia: " + ObjModel.Materia;

                if (Promedio >= 4)
                {
                    string estado = "Estado: Aprobado", promedio = ("Promedio: " + Promedio);
                    ViewBag.estado = estado;
                    ViewBag.promedio = promedio;
                }
                else
                {
                    string estado = "Estado: Reprobado", promedio = ("Promedio: " + Promedio);
                    ViewBag.estado = estado;
                    ViewBag.promedio = promedio;
                }
            }
            return View(ObjModel);
        }

        [HttpPost]
        public ActionResult Ejercicio6(Valores objPresio)
        {
            double Total;
            double TotalPresio = objPresio.Cantidad * objPresio.Precio;
            ViewBag.pagoTotal = TotalPresio;

            if (TotalPresio > 100000)
            {
                Total = TotalPresio - (TotalPresio * 0.20);
                ViewBag.PagoTotal = Total;
            }

            return View(objPresio);
        }
    }
}