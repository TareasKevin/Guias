﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ejercicios_4_y_6.Models
{
    public class Valores
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Materia { get; set; }
        public double Nota1 { get; set; }
        public double Nota2 { get; set; }
        public double Nota3 { get; set; }
        public int Cantidad { get; set; }
        public double Precio { get; set; }
    }
}